from pyautogui import *
import pyautogui as pagui
import time
#import keyboard
import random
import win32api, win32con, win32gui
import cv2 as cv
import os
import pygetwindow


def clickn():
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)


def click(x, y):
    win32api.SetCursorPos((x, y))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)


while desktopativo is None:  # Verifica se o desktop já está
    desktopativo = locateOnScreen('Desktop.png',confidence=0.95)  # visível para a próxima parte.
    print(desktopativo)  # .
    sleep(2)  # .
desktopativo = None

print('# Parte 3: Atualização do W7 para o W10')

sleep(15)
pagui.hotkey('win','2',interval=0.1)  # Abre o Windows Explorer
pagui.press(['tab','enter'],interval=0.25)  # .
pagui.typewrite("D:\win\Win10_1903_V1_BrazilianPortuguese_X64\setup.exe")  # Digita o caminho do setup
pagui.press('enter',interval=0.25)  # .
pagui.hotkey('alt','y')  # .
sleep(10)  # .

print('Procurando o "Upgrade.png"')
while upgradeativo is None:
    upgradeativo = locateOnScreen('Upgrade.png',confidence=0.95)
    print(upgradeativo)
    sleep(2)

sleep(2)
upgradeativo = None
pagui.hotkey('alt','a')
sleep(15)
pagui.hotkey('alt','a')
sleep(2)
pagui.hotkey('alt','a')
sleep(1)
pagui.hotkey('alt','y')
sleep(15)
pagui.hotkey('tab')
sleep(0.5)
pagui.hotkey('enter')
sleep(5)
pagui.hotkey('alt','t')
sleep(195)

print('Procurando o "Upgrade2.png"')

while upgradeativo is None:
    upgradeativo = locateOnScreen('upgrade2.png')
    print(upgradeativo)
    sleep(15)

sleep(1)
upgradeativo = None
pagui.press('tab',presses=10,interval=0.25)
pagui.press('enter')
sleep(600)

print('Procurando o "Upgrade3.png"')
while upgradeativo is None:
    upgradeativo = locateOnScreen('upgrade3.png')
    print(upgradeativo)
    sleep(15)

upgradeativo = None
pagui.hotkey('alt','n')
sleep(2)
pagui.hotkey('alt','a')
sleep(1)
pagui.hotkey('alt','o')
sleep(1)
pagui.hotkey('alt','n')
sleep(15)

print('Procurando o "Upgrade4.png"')
while upgradeativo is None:
    upgradeativo = locateOnScreen('upgrade4.png')
    print(upgradeativo)
    sleep(15)

upgradeativo = None

print('#O Bot terminou um ciclo')
sleep(15)
os.system('taskkill /f /im vmplayer.exe')
num = num + 1

