import os
import pyautogui as pagui
import pygetwindow
import win32api
import win32con
import win32gui
from pyautogui import *

print('iniciando...')


def click(x, y):
    win32api.SetCursorPos((x, y))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
    sleep(0.01)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)


sufixo = input('Qual o sufixo da VM? ')
num = int(input('Valor do "num": '))
instaladorativo = None
desktopativo = None
upgradeativo = None
VMaberta = 0

print('# Parte 1: Começo do Loop de instalação e a criação da Virtual Machine')

while isinstance(num, int) is True:

    numstr = str(num)
    name = ('Windows PPO' + sufixo + '_' + str(num))
    print(name)

    VMaberta = win32gui.FindWindow(None, 'VMware Workstation 16 Player (Non-commercial use only)')
    if VMaberta > 0:
        os.system('taskkill /f /im vmplayer.exe')
    sleep(5)
    win32api.WinExec(r'A:\Programas\VMWare\vmplayer.exe')
    sleep(5)
    pagui.getWindowsWithTitle('VMware Workstation 16 Player')[0].minimize()
    pagui.getWindowsWithTitle('VMware Workstation 16 Player')[0].maximize()
    sleep(1)
    click(70, 80)  # Seleciona o 'Home'
    sleep(1)
    click(478, 136)  # Abre criação da VM
    sleep(1)
    pagui.hotkey('alt', 's')  # Escolher o I will install the operating system later
    sleep(0.5)
    pagui.hotkey('alt', 'n')  # I will install the operating system later
    sleep(0.5)
    pagui.hotkey('alt', 'n')  # Guest operating system
    sleep(0.5)
    pagui.typewrite(name)  # Nome e caminho da VM
    sleep(0.5)  # .
    pagui.hotkey('alt', 'n')  # .
    sleep(0.5)
    pagui.typewrite('32')  # Tamanho do disco da VM e tipo de arquivo
    sleep(0.5)  # .
    pagui.hotkey('alt', 'o')  # Store virtual disk as single file
    sleep(0.5)  # .
    pagui.hotkey('alt', 'n')  # .
    sleep(0.5)
    pagui.hotkey('alt', 'c')  # Customizar sistema
    sleep(0.5)  # .
    pagui.hotkey('alt', 'm')  # Seleciona a memória
    sleep(0.5)  # .
    pagui.typewrite('2048')  # Coloca 2GB de RAM
    sleep(0.5)  # .
    pagui.press('tab')  # -Troca para a parte do leitor de CD virtual
    pagui.press('tab')  # .
    pagui.press('tab')  # .
    pagui.press('tab')  # .
    pagui.press('tab')  # .
    pagui.press('n')  # -
    sleep(0.5)
    pagui.hotkey('alt', 'm')  # Use ISO image file:
    pagui.press('tab')  # Troca pra caixa de texto e (no comando seguinte) escreve o caminho da iso
    pagui.typewrite(r'A:\Sistema\Desktop\Arkivos\VM\ISO\Windows 7\Windows 7 Ultimate SP1.iso')
    pagui.press('enter')  # Finaliza a customização
    sleep(0.5)
    pagui.press('enter')  # Finaliza a criação da VM
    sleep(5)
    pagui.press('tab')    # Inicia a VM
    pagui.press('tab')    #.
    pagui.press('enter')  #.

    print('# Parte 2: Instalação do Winderson 7')

    while instaladorativo is None:                                  #Confirma se o instalador iniciou
        instaladorativo = pagui.locateOnScreen('instalador.png', confidence=0.95)    #.
        print(instaladorativo)                                      #.
        sleep(2)                                                    #.

    win32api.WinExec('osk.exe')                                     #Abre o Teclado virtual pra passar
    sleep(1)                                                        #os inputs para a Vitual Machine
    win = pygetwindow.getWindowsWithTitle('Teclado virtual')[0]     #.
    win.size = (900, 350)                                           #.
    win.moveTo(0, 0)                                                #.
    sleep(1)                                                        #.
    pagui.click('CTRL.png')                                         #.
    sleep(0.5)                                                      #.
    pagui.click('BIGG.png')                                         #.
    sleep(0.5)                                                      #.
    os.system('taskkill /f /im osk.exe')                            #.
    sleep(1)

    instaladorativo = None                                          #Reseta a variável para o outro loop
    sleep(0.25)
    pagui.hotkey('alt', 'n')                                        #Passa pela tela de "idioma"
    sleep(1)
    pagui.hotkey('alt', 'i')                                        #seleciona o "Instalar Agora"

    while instaladorativo is None:                                  #e após, checa se a próxima
        instaladorativo = pagui.locateOnScreen('instalador2.png')   #parte do instalador foi carregado
        print(instaladorativo)                                      #.

    instaladorativo = None                                          #Reseta a variável para o outro loop
    sleep(2)
    pagui.hotkey('alt', 'a')                                        #Aceita os termos e condições
    pagui.hotkey('alt', 'n')                                        #e prossegue para a próxima página
    sleep(1)
    pagui.hotkey('alt', 'c')                                        #Seleciona a Instalação Customizada
    sleep(1)
    pagui.press('enter')                                            #Escolhe o HD de 32GB
    sleep(240)

    while instaladorativo is None:                                  #Checa se o instalador chegou às
        instaladorativo = pagui.locateOnScreen('Fim instalador.png')#configurações finais do mesmo
        print(instaladorativo)                                      #.
        sleep(5)                                                    #.

    sleep(1)
    instaladorativo = None                                          #Reseta a variável

    pagui.typewrite('Key')                                          #Escreve o nome do Perfil
    pagui.hotkey('alt', 'n')                                        #e prossegue
    sleep(1)
    pagui.hotkey('alt', 'n')                                        #Pula as senhas
    sleep(1)
    pagui.hotkey('alt', 'a')                                        #Ignora as atualizações
    sleep(1)
    pagui.hotkey('alt', 'n')                                        #Avança as configurações de hora
    sleep(1)
    pagui.hotkey('alt', 'h')                                        #Seleciona rede "Doméstica"
    sleep(45)                                                       #e aguarda até o final

    while desktopativo is None:                                      #Verifica se o desktop já está
        desktopativo = locateOnScreen('Desktop.png', confidence=0.95)#visível para a próxima parte.
        print(desktopativo)                                          #.
        sleep(2)                                                     #.
    desktopativo = None

    print('# Parte 3: Atualização do W7 para o W10')

    sleep(15)
    pagui.hotkey('win', '2', interval=0.1)                                    #Abre o Windows Explorer
    pagui.press(['tab', 'enter'], interval=0.25)                              #.
    pagui.typewrite("D:\win\Win10_1903_V1_BrazilianPortuguese_X64\setup.exe") #Digita o caminho do setup
    pagui.press('enter', interval=0.25)                                        # .
    pagui.hotkey('alt', 'y')                                                   # .
    sleep(10)  # .

    print('Procurando o "Upgrade.png"')
    while upgradeativo is None:
        upgradeativo = locateOnScreen('Upgrade.png', confidence=0.95)
        print(upgradeativo)
        sleep(2)

    sleep(2)
    upgradeativo = None
    pagui.hotkey('alt', 'a')
    sleep(15)
    pagui.hotkey('alt', 'a')
    sleep(2)
    pagui.hotkey('alt', 'a')
    sleep(1)
    pagui.hotkey('alt', 'y')
    sleep(15)
    pagui.hotkey('tab')
    sleep(0.5)
    pagui.hotkey('enter')
    sleep(5)
    pagui.hotkey('alt', 't')
    sleep(195)


    print('Procurando o "Upgrade2.png"')

    while upgradeativo is None:
        upgradeativo = locateOnScreen('upgrade2.png')
        print(upgradeativo)
        sleep(15)

    sleep(1)
    upgradeativo = None
    pagui.press('tab', presses=10, interval=0.25)
    pagui.press('enter')
    sleep(600)

    print('Procurando o "Upgrade3.png"')
    while upgradeativo is None:
        upgradeativo = locateOnScreen('upgrade3.png')
        print(upgradeativo)
        sleep(15)

    upgradeativo = None
    pagui.hotkey('alt', 'n')
    sleep(2)
    pagui.hotkey('alt', 'a')
    sleep(1)
    pagui.hotkey('alt', 'o')
    sleep(1)
    pagui.hotkey('alt', 'n')
    sleep(15)

    print('Procurando o "Upgrade4.png"')
    while upgradeativo is None:
        upgradeativo = locateOnScreen('upgrade4.png')
        print(upgradeativo)
        sleep(15)

    upgradeativo = None

    print('#O Bot terminou um ciclo')
    sleep(15)
    os.system('taskkill /f /im vmplayer.exe')
    num = num + 1
